Place bomb sprites here (GIF or PNG):
  - Bomb.gif
  - BombExplode.gif

Path in code: /resources/Pickable/
