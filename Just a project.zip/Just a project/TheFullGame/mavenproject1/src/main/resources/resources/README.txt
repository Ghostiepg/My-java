Place ALL images in this folder: src/main/resources/resources/

No subfolders needed for login/register UI - put them directly in "resources":

  LOGIN:        Log.png, blue.gif, yes-1.png, Not-1.png
  REGISTER:     Reg.png, red.gif, yes-1.png, Not-1.png
  FORGOT_PASSWORD: Forgot.png, yellow.gif, yes-1.png, Not-1.png
  FORGOT_USERNAME: FU.png, Screenmark.gif
  GameStart:    Loading.gif, Pixelbombing.png
  PixelBomber:  ICON.png, PixelBOMBER.png
  MainFrame:    ICON.png, HOVERING_ICON.png, MainFrameLogo.png

Subfolders for the game (optional - only if you play Pixel Bomber):

  resources/Props_n_stuff/   Grass.png, B_Brick.png, UB_Brick.png
  resources/Models/          (Blue/Red/Enemy GIFs - see Models/README.txt)
  resources/Pickable/        Bomb.gif, BombExplode.gif

After adding files, rebuild (Clean and Build). "Location is null" is fixed - missing images just won't show.
