/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.sql.*;


public class FORGOT_PASSWORD extends javax.swing.JFrame {

   
    ImageIcon Reg = ImageLoader.load("/resources/Forgot.png");
    BufferedReader reader = null;
    ImageIcon show = ImageLoader.load("/resources/yes-1.png");
    ImageIcon notshow = ImageLoader.load("/resources/Not-1.png");
    boolean passwordVisible = false;
    boolean passwordVisible1 = false;
    public FORGOT_PASSWORD() {
        initComponents();
        
       jTextField1.setText("Enter Phone Number");
        jTextField1.setForeground(Color.GRAY);
        
        Password1.setText("Enter Password");
        Password1.setForeground(Color.GRAY);
        Password1.setEchoChar((char) 0);
        jLabel7.setVisible(false);
        
        Password2.setText("Re-Password");
            Password2.setEchoChar((char)0);
            Password2.setForeground(Color.GRAY);
            jLabel8.setVisible(false);
    }
    
    

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Password1 = new javax.swing.JPasswordField();
        jLabel6 = new javax.swing.JLabel();
        Password2 = new javax.swing.JPasswordField();
        Register = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Forgot Password");
        setIconImage(Reg.getImage()
        );
        setResizable(false);
        addWindowFocusListener(new java.awt.event.WindowFocusListener() {
            public void windowGainedFocus(java.awt.event.WindowEvent evt) {
                formWindowGainedFocus(evt);
            }
            public void windowLostFocus(java.awt.event.WindowEvent evt) {
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        jLabel1.setFont(new java.awt.Font("Comic Sans MS", 1, 26)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Forgot Password");

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/yellow.gif")));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(113, 113, 113)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(189, 189, 189))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 104, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 642, -1));

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextField1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField1FocusLost(evt);
            }
        });
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextField1KeyPressed(evt);
            }
        });
        jPanel2.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(218, 27, 307, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel2.setText("Phone Number:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(107, 30, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel3.setText("New Password:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(107, 70, -1, -1));

        Password1.setEchoChar('\u0000');
        Password1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                Password1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                Password1FocusLost(evt);
            }
        });
        Password1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Password1ActionPerformed(evt);
            }
        });
        jPanel2.add(Password1, new org.netbeans.lib.awtextra.AbsoluteConstraints(218, 67, 307, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel6.setText("Re-Enter Password:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(85, 116, -1, -1));

        Password2.setEchoChar('\u0000');
        Password2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                Password2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                Password2FocusLost(evt);
            }
        });
        Password2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Password2ActionPerformed(evt);
            }
        });
        jPanel2.add(Password2, new org.netbeans.lib.awtextra.AbsoluteConstraints(218, 113, 307, -1));

        Register.setText("Reset");
        Register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegisterActionPerformed(evt);
            }
        });
        jPanel2.add(Register, new org.netbeans.lib.awtextra.AbsoluteConstraints(297, 164, -1, -1));

        jLabel4.setForeground(new java.awt.Color(248, 70, 70));
        jLabel4.setText("Log in?");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(313, 199, -1, -1));

        jLabel7.setIcon(notshow);
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        jLabel7.setVisible(false);
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 70, 51, 30));

        jLabel8.setVisible(false);
        jLabel8.setIcon(notshow);
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 110, 51, 30));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 110, 630, 280));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowGainedFocus(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowGainedFocus

    }//GEN-LAST:event_formWindowGainedFocus

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        passwordVisible1 = !passwordVisible1;

        if (passwordVisible1 == true) {
            Password2.setEchoChar((char)0);
            if (show != null) jLabel8.setIcon(show);
        }
        else {
            Password2.setEchoChar('*');
            if (notshow != null) jLabel8.setIcon(notshow);
        }
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked

        passwordVisible = !passwordVisible;

        if (passwordVisible == true) {
            Password1.setEchoChar((char)0);
            if (show != null) jLabel7.setIcon(show);
        }
        else {
            Password1.setEchoChar('*');
            if (notshow != null) jLabel7.setIcon(notshow);
        }
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        LOGIN log = new LOGIN();
        log.setVisible(true);
        log.pack();
        log.setLocationRelativeTo(null);
        log.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_jLabel4MouseClicked

    private void RegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegisterActionPerformed
        String phone = jTextField1.getText().trim();
    String password = String.valueOf(Password1.getPassword());
    String rePassword = String.valueOf(Password2.getPassword());

    if (phone.isEmpty() || password.isEmpty() || rePassword.isEmpty()
            || phone.equals("Enter Phone Number")
            || password.equals("Enter Password")
            || rePassword.equals("Re-Password")) {
        JOptionPane.showMessageDialog(this, "All fields are required.");
        return;
    }

    if (!password.equals(rePassword)) {
        JOptionPane.showMessageDialog(this, "Passwords do not match.");
        return;
    }

    try {
        Connection con = Database.getConnection();

        String checkSql = "SELECT password FROM Table1 WHERE phone = ?";
        PreparedStatement checkStmt = con.prepareStatement(checkSql);
        checkStmt.setString(1, phone);

        ResultSet rs = checkStmt.executeQuery();

        if (!rs.next()) {
            JOptionPane.showMessageDialog(this, "Phone number not found.");
            return;
        }

        String oldPassword = rs.getString("password");

        if (oldPassword.equals(password)) {
            JOptionPane.showMessageDialog(this, "You can't use the old password.");
            return;
        }

        String updateSql = "UPDATE Table1 SET password = ? WHERE phone = ?";
        PreparedStatement updateStmt = con.prepareStatement(updateSql);
        updateStmt.setString(1, password);
        updateStmt.setString(2, phone);

        updateStmt.executeUpdate();

        JOptionPane.showMessageDialog(this, "Password successfully reset!");

        LOGIN log = new LOGIN();
        log.setVisible(true);
        log.pack();
        log.setLocationRelativeTo(null);
        log.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
    }
    }//GEN-LAST:event_RegisterActionPerformed

    private void Password2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Password2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Password2ActionPerformed

    private void Password2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Password2FocusLost
        if(String.valueOf(Password2.getPassword()).length()==0) {
            Password2.setText("Re-Password");
            Password2.setEchoChar((char)0);
            Password2.setForeground(Color.GRAY);
            jLabel8.setVisible(false);

        }
    }//GEN-LAST:event_Password2FocusLost

    private void Password2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Password2FocusGained
        jLabel8.setVisible(true);

        if(String.valueOf(Password2.getPassword()).equals("Re-Password")) {
            Password2.setText(null);

            Password2.setEchoChar('*');
            Password2.setForeground(Color.BLACK);
            
            Password2.repaint();
        }
    }//GEN-LAST:event_Password2FocusGained

    private void Password1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Password1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Password1ActionPerformed

    private void Password1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Password1FocusLost
        if(String.valueOf(Password1.getPassword()).length()==0) {
            Password1.setText("Enter Password");
            Password1.setEchoChar((char)0);
            Password1.setForeground(Color.GRAY);
            jLabel7.setVisible(false);

        }
    }//GEN-LAST:event_Password1FocusLost

    private void Password1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Password1FocusGained
        jLabel7.setVisible(true);

        if(String.valueOf(Password1.getPassword()).equals("Enter Password")) {
            Password1.setText("");

            Password1.setEchoChar('*');
            Password1.setForeground(Color.BLACK);
            
            Password1.repaint();

        }
    }//GEN-LAST:event_Password1FocusGained

    private void jTextField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField1KeyPressed

    }//GEN-LAST:event_jTextField1KeyPressed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed

    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField1FocusLost
        if (jTextField1.getText().length()==0) {
            jTextField1.setText("Enter Phone Number");
            jTextField1.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_jTextField1FocusLost

    private void jTextField1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField1FocusGained
        if (jTextField1.getText().equals("Enter Phone Number")) {
            jTextField1.setText("");
            jTextField1.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_jTextField1FocusGained

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FORGOT_PASSWORD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FORGOT_PASSWORD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FORGOT_PASSWORD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FORGOT_PASSWORD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FORGOT_PASSWORD().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField Password1;
    private javax.swing.JPasswordField Password2;
    private javax.swing.JButton Register;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
