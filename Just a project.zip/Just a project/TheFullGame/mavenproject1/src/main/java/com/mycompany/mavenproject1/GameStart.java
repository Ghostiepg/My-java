/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.awt.BorderLayout;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author Dell
 */
public class GameStart extends javax.swing.JPanel {

    PixelBomber pb;
    
    public GameStart(PixelBomber pb) {
        initComponents();
        this.pb = pb;
        jButton1.setEnabled(false);
        jButton3.setEnabled(false);
        jProgressBar1.setVisible(false);
        loading();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();

        setBackground(new java.awt.Color(102, 0, 102));
        setPreferredSize(new java.awt.Dimension(756, 560));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        javax.swing.ImageIcon loadingIcon = ImageLoader.load("/resources/Loading.gif");
        if (loadingIcon != null) jLabel2.setIcon(loadingIcon);
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 760, 560));

        jButton1.setFont(new java.awt.Font("Comic Sans MS", 3, 36)); // NOI18N
        jButton1.setText("Play");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(169, 271, 381, 97));

        jButton3.setFont(new java.awt.Font("Comic Sans MS", 3, 18)); // NOI18N
        jButton3.setText("How to Play");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(192, 380, 329, 39));

        javax.swing.ImageIcon pixelIcon = ImageLoader.load("/resources/Pixelbombing.png");
        if (pixelIcon != null) jLabel1.setIcon(pixelIcon);
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(62, 15, -1, -1));
        add(jProgressBar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(736, 546, 10, -1));
    }// </editor-fold>//GEN-END:initComponents
    
    private void loading() {
        new Thread(new Runnable() { 
          @Override
          public void run() {
              try {
                  for (int i = 0; i <= 100; i++) {
                    int value = i;
                    SwingUtilities.invokeLater(() -> jProgressBar1.setValue(value));
                    Thread.sleep(19);
                  }
                  
                  SwingUtilities.invokeLater(() -> {
                        jLabel2.setVisible(false);
                        jButton3.setEnabled(true);
                        jButton1.setEnabled(true); // enable Play button
                  });
                } catch(InterruptedException e) {
                        e.printStackTrace();
                    }
            }
        }).start();
    }
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        pb.showSelection();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        JOptionPane.showMessageDialog(this, "W A S D - Player 1\nE - Bomb (Player 1)\nArrow Keys - Player 2\n'/' - Bomb (Player 2)");
    }//GEN-LAST:event_jButton3ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JProgressBar jProgressBar1;
    // End of variables declaration//GEN-END:variables

    
}
