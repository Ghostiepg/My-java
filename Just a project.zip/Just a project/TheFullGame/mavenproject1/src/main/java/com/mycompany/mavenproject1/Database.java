package com.mycompany.mavenproject1;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Database {

    private static Connection con;
    private static final String DB_NAME = "UsernamePassword.accdb";

    public static Connection getConnection() {
        if (con == null) {
            initializeDatabase();
        }
        return con;
    }

    public static void closeConnection() {
        if (con != null) {
            try {
                con.close();
                con = null;
                System.out.println("Database connection closed.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void initializeDatabase() {
        try {
            // ===== 1. APPDATA LOCATION (main working database) =====
            String userHome = System.getProperty("user.home");
            File appDataFolder = new File(userHome, ".itcp_app");
            appDataFolder.mkdirs();

            File dbFileAppData = new File(appDataFolder, DB_NAME);

            // ===== 2. EXE FOLDER LOCATION (backup) =====
            File exeFolder = new File(System.getProperty("user.dir"));
            File dbFileExe = new File(exeFolder, DB_NAME);

            // ===== 3. MAVEN RESOURCES LOCATION (source) =====
            File resourcesFolder = new File("src/main/resources/resources");
            File dbFileResources = new File(resourcesFolder, DB_NAME);

            // ===== CHECK SCENARIOS =====
            if (dbFileAppData.exists() && dbFileExe.exists()) {
                System.out.println("Both databases exist - using AppData");
            }
            else if (dbFileAppData.exists() && !dbFileExe.exists()) {
                Files.copy(dbFileAppData.toPath(),
                        dbFileExe.toPath(),
                        StandardCopyOption.REPLACE_EXISTING);
                System.out.println("Backup restored from AppData!");
            }
            else if (!dbFileAppData.exists() && dbFileExe.exists()) {
                Files.copy(dbFileExe.toPath(),
                        dbFileAppData.toPath(),
                        StandardCopyOption.REPLACE_EXISTING);
                System.out.println("AppData restored from backup!");
            }
            else if (dbFileResources.exists()) {
                // Copy from Maven resources to AppData and Exe folder
                Files.copy(dbFileResources.toPath(),
                        dbFileAppData.toPath(),
                        StandardCopyOption.REPLACE_EXISTING);
                Files.copy(dbFileResources.toPath(),
                        dbFileExe.toPath(),
                        StandardCopyOption.REPLACE_EXISTING);
                System.out.println("Database copied from Maven resources!");
            }
            else {
                // Try to copy from JAR resources
                copyFromJar(dbFileAppData);
                copyFromJar(dbFileExe);
                System.out.println("Database copied from JAR!");
            }

            String dbPath = dbFileAppData.getAbsolutePath();
            
            // 🔹 FIX: Handle ClassNotFoundException
            try {
                Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            } catch (ClassNotFoundException e) {
                System.err.println("❌ UCanAccess driver not found!");
                e.printStackTrace();
                JOptionPane.showMessageDialog(null,
                        "UCanAccess driver not found. Please check your dependencies.");
                return;
            }

            con = DriverManager.getConnection("jdbc:ucanaccess://" + dbPath);

            System.out.println("✅ DB loaded from: " + dbPath);

        } catch (IOException | SQLException e) {
            System.err.println("❌ Database connection failed: " + e.getMessage());
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,
                    "Database connection failed! " + e.getMessage());
        }
    }

    private static void copyFromJar(File destination) throws IOException {
        try (InputStream inputStream =
                     Database.class.getResourceAsStream("/resources/" + DB_NAME)) {

            if (inputStream == null) {
                throw new FileNotFoundException("DB not found in JAR resources at /resources/" + DB_NAME);
            }

            Files.copy(inputStream, destination.toPath(),
                    StandardCopyOption.REPLACE_EXISTING);
        }
    }
}