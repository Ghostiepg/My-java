    /*
     * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
     * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
     */
    package com.mycompany.mavenproject1;

    import java.awt.event.KeyEvent;
    import java.awt.event.KeyListener;

    public class KeyInputs implements KeyListener{
        // Simple edge-triggered inputs. The update loop reads these booleans each tick.
        // Movement uses hold-state (up/down/left/right, aup/adown/aleft/aright).
        // Bomb placement sets a flag and is cleared by GamePanel after placing.

        public volatile boolean up, down, left, right;
        public volatile boolean placeBomb, placeBombRed;
        public volatile boolean aup, adown, aleft, aright;

        @Override
        public void keyPressed(KeyEvent e) {
            switch (e.getKeyCode()) {
                // Blue
                case KeyEvent.VK_W -> up = true;
                case KeyEvent.VK_S -> down = true;
                case KeyEvent.VK_A -> left = true;
                case KeyEvent.VK_D -> right = true;
                case KeyEvent.VK_E -> placeBomb = true;

                // Red
                case KeyEvent.VK_UP -> aup = true;
                case KeyEvent.VK_DOWN -> adown = true;
                case KeyEvent.VK_LEFT -> aleft = true;
                case KeyEvent.VK_RIGHT -> aright = true;
                case KeyEvent.VK_SLASH -> placeBombRed = true;

            }
        }

        @Override
        public void keyReleased(KeyEvent e) {
            switch (e.getKeyCode()) {
                // Blue
                case KeyEvent.VK_W -> up = false;
                case KeyEvent.VK_S -> down = false;
                case KeyEvent.VK_A -> left = false;
                case KeyEvent.VK_D -> right = false;
                case KeyEvent.VK_E -> placeBomb = false;

                // Red
                case KeyEvent.VK_UP -> aup = false;
                case KeyEvent.VK_DOWN -> adown = false;
                case KeyEvent.VK_LEFT -> aleft = false;
                case KeyEvent.VK_RIGHT -> aright = false;
                case KeyEvent.VK_SLASH -> placeBombRed = false;

            }
        }

        @Override
        public void keyTyped(KeyEvent e) {}


    }
