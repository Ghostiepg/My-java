package com.mycompany.mavenproject1;

import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.metadata.IIOMetadataNode;
import javax.swing.ImageIcon;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class GifDecoder {
    private BufferedImage[] frames;
    private int[] delays;
    private int currentFrame = 0;
    private long lastFrameTime = 0;
    private int frameDelay = 100;

    public GifDecoder(String path) {
        try {
            java.net.URL url = GifDecoder.class.getResource(path);
            if (url != null) {
                BufferedImage img = ImageIO.read(url);
                // For now, just use the first frame
                frames = new BufferedImage[]{img};
                delays = new int[]{100};
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public BufferedImage getCurrentFrame(long currentTime) {
        if (frames == null || frames.length == 0) return null;
        
        if (currentTime - lastFrameTime >= delays[currentFrame]) {
            currentFrame = (currentFrame + 1) % frames.length;
            lastFrameTime = currentTime;
        }
        return frames[currentFrame];
    }

    public int getFrameCount() {
        return frames != null ? frames.length : 0;
    }
}