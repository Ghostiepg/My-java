/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package com.mycompany.mavenproject1;

import Characters.Blue;
import Characters.Enemies;
import Characters.Red;
import Prop_Coding.Bomb;

import Prop_Coding.Tiles_Manager;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import java.awt.Rectangle;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;


/**
 *
 * @author Dell
 */
public class GamePanel extends javax.swing.JPanel implements Runnable {

    final int OTS = 16;
    public final int scale = 3;
    
    public final int TS = OTS * scale;
    public final int MSC = 16;
    public final int MSR = 12;
    public boolean gameEnded = false; // add this at the top
    public int players;
    
    
        public final int FPS = 60; // ✅ Make it final
        
    
    Tiles_Manager tileM = new Tiles_Manager(this);
    KeyInputs keyH = new KeyInputs();
    KeyInputs keyR = new KeyInputs();

    Thread GT;
    public ArrayList<Enemies> enemies = new ArrayList<>();
    public CollisionChecka CC = new CollisionChecka(this);
    public ArrayList<Bomb> bombs = new ArrayList<>();
    public ArrayList<Rectangle> explodeHitboxes = new ArrayList<>();
    
    Blue blue;
    Red red;
    
    public int TotalRound = 1;
    public int currentRound = 1;
    public boolean infRounds = false;
    
    public int bScore = 0;
    public int rScore = 0;
    
    
    public boolean blueAliveLastRound = true;
    public boolean redAliveLastRound = true;
    public boolean enemiesAliveLastRound = true;
    
     private int enemiesCount;
    
    
    private PixelBomber pb;
    private volatile boolean running = false;
    private long tickCounter = 0;
    private long blueDeathTick = -1;
    private long redDeathTick = -1;
    private int roundEndWaitTicks = 0;
    private String pendingRoundMsg = null;


    public GamePanel(int players, int enemiesCount, int rounds, boolean infinite, PixelBomber pb) {
    this.players = players;
    this.enemiesCount = enemiesCount;
    initComponents();

    this.pb = pb;
    this.TotalRound = rounds;
    this.infRounds = infinite;

    this.setDoubleBuffered(true);
    this.addKeyListener(keyH);
    this.addKeyListener(keyR);
    this.setFocusable(true);
    this.requestFocusInWindow(); 

    resetRound();
    spawnEnemies();  // start with enemies
    startThread();   // start game loop
    
    
    
}
    
    

    public void stopGame() {
        running = false;
        if (GT != null) {
            if (GT != Thread.currentThread()) {
                try {
                    GT.join(200);
                } catch (InterruptedException ignored) {}
            }
            GT = null;
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setBackground(new java.awt.Color(0, 0, 0));
        setPreferredSize(new java.awt.Dimension(756, 560));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 756, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 560, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents
    public void startThread() {
        if (GT != null) return;
        running = true;
        GT = new Thread(this, "GameLoop");
        GT.start();
    }
    
    public void placebomb(){
        int bombX = ( blue.x + TS / 2 )  / TS;
        int bombY = ( blue.y + TS / 2 )  / TS;
        
        for (Bomb z : new ArrayList<>(bombs)) {
            if (z.x == bombX && z.y == bombY) return;
        }
        
        bombs.add(new Bomb(bombX, bombY));
        blue.LBX = bombX;
        blue.LBY = bombY;
    }
    
        public void placeBombRed() {
        int bombX = ( red.x + TS / 2 )  / TS;
        int bombY = ( red.y + TS / 2 )  / TS;

        for (Bomb z : new ArrayList<>(bombs)) {
            if (z.x == bombX && z.y == bombY) return;
        }

        bombs.add(new Bomb(bombX, bombY));

        red.LBX = bombX;
        red.LBY = bombY;
    }
    
        @Override
    public void run() {
        final double nsPerUpdate = 1_000_000_000.0 / FPS;
        double delta = 0.0;
        long last = System.nanoTime();

        while (running) {
            long now = System.nanoTime();
            delta += (now - last) / nsPerUpdate;
            last = now;

            int steps = 0;
            final int maxSteps = 3;
            while (delta >= 1.0 && running && steps < maxSteps) {
                update();
                tickCounter++;
                delta -= 1.0;
                steps++;
            }

            repaint();

            try {
                Thread.sleep(16);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    public int[] getRandomSafeTileForPlayer() {
        int charWidthTiles = (blue.solidArea.width + TS - 1) / TS;   // ceil division
        int charHeightTiles = (blue.solidArea.height + TS - 1) / TS; // ceil division

        while (true) {
            int col = (int) (Math.random() * (MSC - charWidthTiles));
            int row = (int) (Math.random() * (MSR - charHeightTiles));

            boolean safe = true;

            // Check all tiles that would be under the character's solid area
            for (int dx = 0; dx < charWidthTiles; dx++) {
                for (int dy = 0; dy < charHeightTiles; dy++) {
                    int tile = tileM.MTN[col + dx][row + dy];
                    if (tileM.tile[tile].collision) {
                        safe = false;
                        break;
                    }
                }
                if (!safe) break;
            }

            if (!safe) continue;

            // Optional: Avoid spawning in corners immediately next to walls
            if (col <= 0 || row <= 0 || col + charWidthTiles >= MSC || row + charHeightTiles >= MSR) continue;

            return new int[]{col, row};
        }
    }


    private void drawScoreboard(Graphics2D g2) {

    g2.setColor(new Color(0, 0, 0, 180));
    g2.fillRect(10, 10, 180, 80);

    g2.setColor(Color.WHITE);
    String roundDisplay = infRounds ? "∞" : currentRound + "/" + TotalRound;
    g2.drawString("Round: " + roundDisplay, 20, 25);

    g2.setColor(Color.BLUE);
    g2.drawString("Blue: " + bScore, 20, 45);

    if (players == 2) {
        g2.setColor(Color.RED);
        g2.drawString("Red: " + rScore, 20, 65);
    }
}



    
    public boolean destroyTile(int x, int y) {
        if (x >= 0 && y >= 0 && x < MSC && y < MSR) {
            int tile = tileM.MTN[x][y];
            
            if (tile == 1) {
                tileM.MTN[x][y] = 0;
                return false;
            }
            
            if (tile == 2) {
                return false;
            }
            return true;
        }
        return false;
    }
    public boolean canExplode(int x, int y) {
        if (x < 0 || y < 0 || x >= MSC || y >= MSR) return false;
        int tile = tileM.MTN[x][y];
        return tile == 0 || tile == 1;
    }
    
    
    
                                                                                                                                                        
    private void endRoundAndShowDialog(String customMsg) {
    gameEnded = true;
    stopGame();

    String msg = customMsg != null ? customMsg :
                 bScore > rScore ? "Blue Wins!" :
                 rScore > bScore ? "Red Wins!" :
                 "It's a Draw!";

    Object[] options;
    boolean canProceed = infRounds || currentRound < TotalRound;

    if (canProceed) {
        options = new Object[]{"Proceed", "Return to Menu"};
    } else {
        options = new Object[]{"Return to Menu"};
    }

    String scoreLine = (players == 2) ? ("\nBlue: " + bScore + "  Red: " + rScore) : "";
    final int[] optionHolder = new int[]{JOptionPane.CLOSED_OPTION};
    try {
        javax.swing.SwingUtilities.invokeAndWait(() -> {
            optionHolder[0] = JOptionPane.showOptionDialog(
                this,
                "Game Over\n" + msg + scoreLine,
                "Game Over",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                options,
                options[0]
            );
        });
    } catch (Exception e) {
        e.printStackTrace();
    }
    int option = optionHolder[0];
    if (option == JOptionPane.CLOSED_OPTION) {
        option = canProceed ? 1 : 0;
    }

        if (canProceed) {
        if (option == 0) { // "Proceed"
            currentRound++;
            resetRound();
            gameEnded = false;
            startThread(); // restart game loop
            SwingUtilities.invokeLater(this::requestFocusInWindow);
        } else {           // "Return to Menu"
            stopGame();
            SwingUtilities.invokeLater(pb::removeGameAndShowSelection);
        }
    } else {
        // Only "Return to Menu"
        stopGame();
        SwingUtilities.invokeLater(pb::removeGameAndShowSelection);
    }
}

    public void showGameOverPanel() {
        endRoundAndShowDialog(null);
    }
    public void checkRoundEnd() {

    if (gameEnded) return;

    boolean blueDead = !blue.alive && blue.DT <= 0;
    boolean redDead = red == null || (!red.alive && red.DT <= 0);
    boolean allEnemiesDead = enemies.stream().allMatch(e -> !e.alive);

    // ---- SINGLE PLAYER ----
    if (players == 1) {

        // Trigger end-of-round as soon as Blue dies, but let animation play
        if (!blue.alive) {
            gameEnded = true;
            pendingRoundMsg = "Blue Lost!";
            roundEndWaitTicks = Math.max(roundEndWaitTicks, blue.DT);
            keyH.up = keyH.down = keyH.left = keyH.right = keyH.placeBomb = false;
            return;
        }

        if (allEnemiesDead) {
            gameEnded = true;
            pendingRoundMsg = "Blue Wins!";
            roundEndWaitTicks = 60;
            keyH.up = keyH.down = keyH.left = keyH.right = keyH.placeBomb = false;
            return;
        }
    }

    // ---- MULTIPLAYER ----
    if (players == 2) {

        boolean roundOver = (blueDead && redDead) || allEnemiesDead;

        if (!roundOver) return;

        String roundMsg;
        if (blueDead && redDead) {
            boolean blueLater = blueDeathTick >= redDeathTick;
            if (blueLater) {
                roundMsg = "Blue Wins!";
                bScore++;
            } else {
                roundMsg = "Red Wins!";
                rScore++;
            }
        } else if (allEnemiesDead) {
            if (!blueDead && redDead) {
                roundMsg = "Blue Wins!";
                bScore++;
            } else if (!redDead && blueDead) {
                roundMsg = "Red Wins!";
                rScore++;
            } else {
                roundMsg = "Blue Wins!"; // tie-break when both alive: favor Blue
                bScore++;
            }
        } else {
            if (!blueDead) { bScore++; roundMsg = "Blue Wins!"; }
            else { rScore++; roundMsg = "Red Wins!"; }
        }

        gameEnded = true;
        pendingRoundMsg = roundMsg;
        roundEndWaitTicks = 60;
        keyH.up = keyH.down = keyH.left = keyH.right = keyH.placeBomb = false;
        keyR.aup = keyR.adown = keyR.aleft = keyR.aright = keyR.placeBombRed = false;
    }
}


    public void resetRound() {

        blue = new Blue(this, keyH);
        

        int[] blueSpawn = getRandomSafeTileForPlayer();
        blue.x = blueSpawn[0] * TS;
        blue.y = blueSpawn[1] * TS;

        if (players == 2) {
            red = new Red(this, keyR);
            

            int[] redSpawn;
            do {
                redSpawn = getRandomSafeTileForPlayer();
            } while (redSpawn[0] == blueSpawn[0] && redSpawn[1] == blueSpawn[1]);

            red.x = redSpawn[0] * TS;
            red.y = redSpawn[1] * TS;
        } else {
            red = null;
        }

        bombs.clear();
        enemies.clear();
        explodeHitboxes.clear();

        tileM.reloadMap();
        spawnEnemies();

        keyH.up = keyH.down = keyH.left = keyH.right = keyH.placeBomb = false;
        keyR.aup = keyR.adown = keyR.aleft = keyR.aright = keyR.placeBombRed = false;
        blueDeathTick = -1;
        redDeathTick = -1;
        roundEndWaitTicks = 0;
        pendingRoundMsg = null;

        this.setFocusable(true);
        SwingUtilities.invokeLater(() -> this.requestFocusInWindow());
    }


    
    public void spawnEnemies() {
         enemies.clear();
         
        for (int i = 0; i < enemiesCount; i++) {
            enemies.add(new Enemies(this, 3, 3));
        }
    }
    

    
    
    
        
    
        public void paintComponent(Graphics g) {
        
        super.paintComponent(g);
        
        Graphics2D g2 = (Graphics2D)g;
        
        tileM.draw(g2);
        
        for (Bomb z : new ArrayList<>(bombs)) {
            int screenX = z.x * TS;
            int screenY = z.y * TS;

            if (!z.exploded) {
                if (z.bomb != null) g2.drawImage(z.bomb, screenX, screenY, TS, TS, this);
            } else {
                if (z.c != null) g2.drawImage(z.c, screenX, screenY, TS, TS, this);

                for (int i = 1; i <= z.range; i++) {
                    int tx = z.x - i;
                    if (!canExplode(tx, z.y)) break;
                    int px = tx * TS;
                    if (i == z.range || !canExplode(tx - 1, z.y)) {
                        if (z.l != null) g2.drawImage(z.l, px, screenY, TS, TS, this);
                        break;
                    }
                    if (z.lp != null) g2.drawImage(z.lp, px, screenY, TS, TS, this);
                }
                for (int i = 1; i <= z.range; i++) {
                    int tx = z.x + i;
                    if (!canExplode(tx, z.y)) break;
                    int px = tx * TS;
                    if (i == z.range || !canExplode(tx + 1, z.y)) {
                        if (z.r != null) g2.drawImage(z.r, px, screenY, TS, TS, this);
                        break;
                    }
                    if (z.rp != null) g2.drawImage(z.rp, px, screenY, TS, TS, this);
                }
                for (int i = 1; i <= z.range; i++) {
                    int ty = z.y - i;
                    if (!canExplode(z.x, ty)) break;
                    int py = ty * TS;
                    if (i == z.range || !canExplode(z.x, ty - 1)) {
                        if (z.u != null) g2.drawImage(z.u, screenX, py, TS, TS, this);
                        break;
                    }
                    if (z.upp != null) g2.drawImage(z.upp, screenX, py, TS, TS, this);
                }
                for (int i = 1; i <= z.range; i++) {
                    int ty = z.y + i;
                    if (!canExplode(z.x, ty)) break;
                    int py = ty * TS;
                    if (i == z.range || !canExplode(z.x, ty + 1)) {
                        if (z.d != null) g2.drawImage(z.d, screenX, py, TS, TS, this);
                        break;
                    }
                    if (z.dpp != null) g2.drawImage(z.dpp, screenX, py, TS, TS, this);
                }
            }
        }
            
            blue.draw(g2);

            if (players == 2 && red != null) {
                red.draw(g2);
            }


            for (Enemies e : new ArrayList<>(enemies)) {
                e.draw(g2);
            }

            
            
            drawScoreboard(g2);
            if (gameEnded && roundEndWaitTicks > 0) {
                g2.setColor(new Color(0, 0, 0, 160));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(Color.WHITE);
                int seconds = Math.max(0, roundEndWaitTicks / FPS);
                String msg = (pendingRoundMsg != null) ? pendingRoundMsg : "Round Over";
                g2.drawString(msg, 20, 40);
                g2.drawString("Proceeding in: " + seconds + "s", 20, 60);
            }
            g2.dispose();
    }  // ✅ Add this closing brace for paintComponent()
    
        
        public void update() {
       
        
        if (gameEnded) {
            if (roundEndWaitTicks > 0) {
                roundEndWaitTicks--;
                // still let timers in bombs and DTs progress
            } else if (pendingRoundMsg != null) {
                endRoundAndShowDialog(pendingRoundMsg);
                pendingRoundMsg = null;
            }
        }
        
        
         blue.update();
         
        if (keyH.placeBomb && blue.alive) {
            placebomb();
            keyH.placeBomb = false;
        }
        if (players == 2 && red != null) {
            
            red.update();
        }

        
        
        
        if (players == 2 && red != null && keyR.placeBombRed && red.alive) {
                placeBombRed();
                keyR.placeBombRed = false;
            }
        
        ArrayList<Bomb> toRemove = new ArrayList<>();
        
        
        for (Bomb z : new ArrayList<>(bombs)) {
            z.timer++;
            
                  if (z.timer >= z.ECD + 45) {
          toRemove.add(z);
      }
            
                if (z.exploded && z.timer < z.ECD + 30) {
                    explodeHitboxes.addAll(z.ahitbox);
                }
            
            if (z.timer == z.ECD) {
                z.exploded = true;
                
                destroyTile(z.x, z.y);
                z.ahitbox.add(new Rectangle(z.x * TS, z.y * TS, TS, TS));
                
                for (int i = 1; i <= z.range; i++) {
                    if (!destroyTile(z.x - i, z.y)) break;
                    z.ahitbox.add(new Rectangle((z.x - i) * TS, z.y * TS, TS, TS));
                }
                for (int i = 1; i <= z.range; i++) {
                    if (!destroyTile(z.x + i, z.y)) break;
                    z.ahitbox.add(new Rectangle((z.x + i) * TS, z.y * TS, TS, TS));
                }
                for (int i = 1; i <= z.range; i++) {
                    if (!destroyTile(z.x, z.y - i)) break;
                    z.ahitbox.add(new Rectangle(z.x * TS, (z.y - i) * TS, TS, TS));
                }
                for (int i = 1; i <= z.range; i++) {
                    if (!destroyTile(z.x, z.y + i)) break;
                    z.ahitbox.add(new Rectangle(z.x * TS, (z.y + i) * TS, TS, TS));
                }
            }
           
                if (blue.alive) {
            Rectangle onebox = new Rectangle(blue.x, blue.y, TS,TS);
            ArrayList<Rectangle> hitboxesSnapshot = new ArrayList<>(explodeHitboxes);
            for (Rectangle hb : hitboxesSnapshot) {
                if (hb != null && onebox.intersects(hb)) {
                    blueDeathTick = tickCounter;
                    blue.kill();
                    
                    break;
                }
            }
        }
                if (players == 2 && red != null && red.alive) {
                    Rectangle twobox = new Rectangle(red.x, red.y, TS, TS);
                    for (Rectangle hb : new ArrayList<>(explodeHitboxes)) {
                        if (hb != null && twobox.intersects(hb)) {
                            redDeathTick = tickCounter;
                            red.kill();
                            break;
                        }
                    }
                }
                
                
        
                ArrayList<Enemies> deadE = new ArrayList<>();
        
        for (Enemies e : new ArrayList<>(enemies)) {
            e.update();
            
            if (e.alive) {
                Rectangle ebox = new Rectangle(e.x, e.y, TS,TS);
            ArrayList<Rectangle> hitboxesSnapshot3 = new ArrayList<>(explodeHitboxes);
            for (Rectangle hb : hitboxesSnapshot3) {
                if (hb != null && ebox.intersects(hb)) {
                    e.kill();
                    
                    break;
                }
            }
            // contact damage to players
            if (blue.alive) {
                Rectangle onebox = new Rectangle(
                    blue.x + blue.solidArea.x,
                    blue.y + blue.solidArea.y,
                    blue.solidArea.width,
                    blue.solidArea.height
                );
                if (onebox.intersects(ebox)) {
                    blueDeathTick = tickCounter;
                    blue.kill();
                }
            }
            if (players == 2 && red != null && red.alive) {
                Rectangle twobox = new Rectangle(
                    red.x + red.solidArea.x,
                    red.y + red.solidArea.y,
                    red.solidArea.width,
                    red.solidArea.height
                );
                if (twobox.intersects(ebox)) {
                    redDeathTick = tickCounter;
                    red.kill();
                }
            }
            } else {
                if (e.DT <= 0) {
                    deadE.add(e);
                }
            }
        }
        enemies.removeIf(deadE::contains);

        explodeHitboxes.clear();
        bombs.removeIf(toRemove::contains);
        checkRoundEnd();
    }
    
    
    // Variables declaration - do not modify                     
    // End of variables declaration                   
  // ✅ This is the END of the CLASS

    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
        }
}
