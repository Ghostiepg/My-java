    package com.mycompany.mavenproject1;

import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.sql.*;

public class LOGIN extends javax.swing.JFrame {

    
    private ImageIcon Log = ImageLoader.load("/resources/Log.png");
    private ImageIcon blue = ImageLoader.load("/resources/blue.gif");
    private ImageIcon show = ImageLoader.load("/resources/yes-1.png");
    private ImageIcon notshow = ImageLoader.load("/resources/Not-1.png");
    
    boolean passwordVisible = false;
    int count = 0;
    
    public LOGIN() {
        initComponents();
        listeners();
        
        Username.setText("Enter Username");
        Username.setForeground(Color.GRAY);
        
        Password.setText("Enter Password");
        Password.setForeground(Color.GRAY);
        Password.setEchoChar((char) 0);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Tab = new javax.swing.JPanel();
        TextLogIn = new javax.swing.JLabel();
        Blue = new javax.swing.JLabel();
        MainTab = new javax.swing.JPanel();
        TextUsername = new javax.swing.JLabel();
        Username = new javax.swing.JTextField();
        TextPassword = new javax.swing.JLabel();
        Password = new javax.swing.JPasswordField();
        LogInButton = new javax.swing.JButton();
        Register = new javax.swing.JButton();
        ForgotPass = new javax.swing.JLabel();
        shownotshow = new javax.swing.JLabel();
        ForgotUser = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Log in");
        setBackground(new java.awt.Color(41, 44, 47));
        setIconImage(Log.getImage());
        setLocation(new java.awt.Point(0, 0));
        setResizable(false);

        Tab.setBackground(new java.awt.Color(51, 51, 51));

        TextLogIn.setBackground(new java.awt.Color(102, 0, 102));
        TextLogIn.setFont(new java.awt.Font("Comic Sans MS", 1, 26)); // NOI18N
        TextLogIn.setForeground(new java.awt.Color(255, 255, 255));
        TextLogIn.setText("Login Account");

        Blue.setIcon(blue
        );

        javax.swing.GroupLayout TabLayout = new javax.swing.GroupLayout(Tab);
        Tab.setLayout(TabLayout);
        TabLayout.setHorizontalGroup(
            TabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TabLayout.createSequentialGroup()
                .addContainerGap(91, Short.MAX_VALUE)
                .addComponent(Blue, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(TextLogIn)
                .addGap(216, 216, 216))
        );
        TabLayout.setVerticalGroup(
            TabLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TabLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(TextLogIn)
                .addContainerGap(33, Short.MAX_VALUE))
            .addComponent(Blue, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        MainTab.setBackground(new java.awt.Color(225, 225, 225));
        MainTab.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TextUsername.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        TextUsername.setText("Username:");
        MainTab.add(TextUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(115, 55, -1, -1));

        Username.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UsernameActionPerformed(evt);
            }
        });
        MainTab.add(Username, new org.netbeans.lib.awtextra.AbsoluteConstraints(209, 52, 300, -1));

        TextPassword.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        TextPassword.setText("Password:");
        MainTab.add(TextPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(117, 95, -1, -1));

        Password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PasswordActionPerformed(evt);
            }
        });
        MainTab.add(Password, new org.netbeans.lib.awtextra.AbsoluteConstraints(209, 92, 300, -1));

        LogInButton.setText("Log in");
        LogInButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogInButtonActionPerformed(evt);
            }
        });
        MainTab.add(LogInButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(437, 144, -1, -1));

        Register.setText("Create Account?");
        MainTab.add(Register, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 188, -1, -1));

        ForgotPass.setText("<html><u><font color='blue'>Forgot Password?</font></u><html>");
        ForgotPass.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ForgotPass.setVisible(false);
        MainTab.add(ForgotPass, new org.netbeans.lib.awtextra.AbsoluteConstraints(346, 217, 118, -1));

        shownotshow.setIcon(notshow);
        shownotshow.setVisible(false);
        MainTab.add(shownotshow, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 90, 40, 30));

        ForgotUser.setText("<html><u><font color='red'>Forgot Username?</font></u><html>");
        ForgotUser.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ForgotUser.setVisible(false);
        MainTab.add(ForgotUser, new org.netbeans.lib.awtextra.AbsoluteConstraints(138, 217, 119, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(Tab, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(MainTab, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Tab, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(MainTab, javax.swing.GroupLayout.DEFAULT_SIZE, 271, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void LogInButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogInButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_LogInButtonActionPerformed

    private void PasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PasswordActionPerformed

    private void UsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UsernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UsernameActionPerformed

     private void listeners() {
        
        ForgotPass.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dispose1();
            }
        });
        
        Register.addActionListener((java.awt.event.ActionEvent evt) -> {
            dispose2();
        });
        
        LogInButton.addActionListener((java.awt.event.ActionEvent evt) -> {
            String user = Username.getText();
    String pass = String.valueOf(Password.getPassword());

    if (user.equals("Enter Username") || pass.equals("Enter Password")
        || user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(null,"Text Fields must be filled.","Error Message!",JOptionPane.ERROR_MESSAGE);
            return;
    }

    try {
        Connection conn = Database.getConnection();

        String sql = "SELECT * FROM Table1 WHERE username=? AND password=?";
        PreparedStatement ps = conn.prepareStatement(sql);

        ps.setString(1, user);
        ps.setString(2, pass);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            JOptionPane.showMessageDialog(null, "Login Successfully");

            MainFrame mfra = new MainFrame();
            mfra.setVisible(true);
            mfra.pack();
            mfra.setLocationRelativeTo(null);
            mfra.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.dispose();

        } else {
            JOptionPane.showMessageDialog(null,
                    "Wrong Username or Wrong Password.",
                    "Error Message!",
                    JOptionPane.ERROR_MESSAGE);
            count++;
        }

        if (count >= 5) {
            ForgotUser.setVisible(true);
            ForgotPass.setVisible(true);
        }

        rs.close();
        ps.close();
        conn.close();

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null,
                "Database Error: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }});
        
        Password.addFocusListener(new java.awt.event.FocusAdapter() {
            
            @Override
            public void focusGained(java.awt.event.FocusEvent evt) {
                shownotshow.setVisible(true);
        
                if(String.valueOf(Password.getPassword()).equals("Enter Password")) {
                Password.setText("");
                Password.setEchoChar('*');
                Password.setForeground(Color.BLACK);
                Password.repaint();
                }
            }
            
            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                if(String.valueOf(Password.getPassword()).length()==0) {
                Password.setText("Enter Password");
                Password.setEchoChar((char)0);
                Password.setForeground(Color.GRAY);
                shownotshow.setVisible(false);
                }
            }
        });
            
            
        
        Username.addFocusListener(new java.awt.event.FocusAdapter() {
            
            @Override
            public void focusGained(java.awt.event.FocusEvent evt) {
                 if (Username.getText().equals("Enter Username")) {
                    Username.setText("");
                    Username.setForeground(Color.BLACK);
                }
            }
            
            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                if (Username.getText().length()==0) {
                    Username.setText("Enter Username");
                    Username.setForeground(Color.GRAY);
                }
            }
        });
        
        shownotshow.addMouseListener(new java.awt.event.MouseAdapter() {
            
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                passwordVisible = !passwordVisible;
        
                if (passwordVisible == true) {
                    Password.setEchoChar((char)0);
                    if (show != null) shownotshow.setIcon(show);
                }
                else {
                    Password.setEchoChar('*');
                    if (notshow != null) shownotshow.setIcon(notshow);
                }
            }
        });
        
        ForgotUser.addMouseListener(new java.awt.event.MouseAdapter() {
            
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dispose3();
            }
        });
        
    }
    
    private void dispose1() {
        FORGOT_PASSWORD fp = new FORGOT_PASSWORD();
        fp.setVisible(true);
        fp.pack();
        fp.setLocationRelativeTo(null);
        fp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }
    
    private void dispose2() {
        REGISTER reg = new REGISTER();
        reg.setVisible(true);
        reg.pack();
        reg.setLocationRelativeTo(null);
        reg.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }  
    
    private void dispose3() {
        FORGOT_USERNAME fu = new FORGOT_USERNAME();
        fu.setVisible(true);
        fu.pack();
        fu.setLocationRelativeTo(null);
        fu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> {
            new LOGIN().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Blue;
    private javax.swing.JLabel ForgotPass;
    private javax.swing.JLabel ForgotUser;
    private javax.swing.JButton LogInButton;
    private javax.swing.JPanel MainTab;
    private javax.swing.JPasswordField Password;
    private javax.swing.JButton Register;
    private javax.swing.JPanel Tab;
    private javax.swing.JLabel TextLogIn;
    private javax.swing.JLabel TextPassword;
    private javax.swing.JLabel TextUsername;
    private javax.swing.JTextField Username;
    private javax.swing.JLabel shownotshow;
    // End of variables declaration//GEN-END:variables
}
