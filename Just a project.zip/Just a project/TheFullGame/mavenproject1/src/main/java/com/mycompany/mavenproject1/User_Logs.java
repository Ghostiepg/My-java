/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

public class User_Logs {
    public String name;
    public String first;
    public String last;
    public String phone;
    public String gender;
    public String pass;
        
        public User_Logs(String name, String pass, String last, String first, String phone, String gender) {
            this.name = name;
            this.pass = pass;
            this.last = last;
            this.first = first;
            this.phone = phone;
            this.gender = gender;
        }
}
