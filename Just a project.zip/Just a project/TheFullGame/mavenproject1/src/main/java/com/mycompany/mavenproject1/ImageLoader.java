package com.mycompany.mavenproject1;

import javax.swing.ImageIcon;


public final class ImageLoader {

    public static ImageIcon load(String path) {
        if (path == null || path.isEmpty()) return null;
        java.net.URL url = ImageLoader.class.getResource(path);
        return (url != null) ? new ImageIcon(url) : null;
    }
}
