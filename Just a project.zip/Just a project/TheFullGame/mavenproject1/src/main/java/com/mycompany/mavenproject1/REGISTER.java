/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.*;


import java.time.Year;


public class REGISTER extends javax.swing.JFrame {


    ImageIcon Reg = ImageLoader.load("/resources/Reg.png");
    ImageIcon red = ImageLoader.load("/resources/red.gif");
    ImageIcon show = ImageLoader.load("/resources/yes-1.png");
    ImageIcon notshow = ImageLoader.load("/resources/Not-1.png");
    
    boolean passwordVisible = false;
    boolean passwordVisible1 = false;
    public String gender;
    private boolean isReviewed = false;
    private int count = 0;
    
    public REGISTER() {
        initComponents();
        jCalendar();
        
        
        
        ButtonGroup Gg = new ButtonGroup();
        Gg.add(jRadioButton1);
        Gg.add(jRadioButton2);
        Gg.add(jRadioButton3);
        
        FirstName.setText("First Name");
        FirstName.setForeground(Color.GRAY);
        
        jTextField3.setText("Middle Name");
        jTextField3.setForeground(Color.GRAY);
        
        jTextField4.setText("Last Name");
        jTextField4.setForeground(Color.GRAY);
        
        jTextField1.setText("Enter Phone Number");
        jTextField1.setForeground(Color.GRAY);
        
        jTextField2.setText("Enter Username");
        jTextField2.setForeground(Color.GRAY);
        
            Password1.setText("Enter Password");
            Password1.setForeground(Color.GRAY);
            Password1.setEchoChar((char)0);
            jLabel7.setVisible(false);
        
        Password2.setText("Re-Enter Password");
            Password2.setEchoChar((char)0);
            Password2.setForeground(Color.GRAY);
            jLabel8.setVisible(false);
            
        
    }
    
    public class DUli {
        public static String[] getYears() {
            int startYear = 1990;
            int endyear = java.time.Year.now().getValue();
            int length = endyear - startYear + 1;
            String[] years = new String[length];
            
                for (int i = 0; i < length; i++) {
                    years[i] = String.valueOf(endyear - i);
                }
        return years;
        } // Getting the years to add
        
        public static String[] getDays(int years, int MI) {
            int DM;
            
            switch (MI) {
                case 1 -> DM = Year.isLeap(years) ? 29 : 28;
                case 3, 5, 8,10 -> DM = 30;
                default -> DM = 31;
            }
            
            
  
            String[] days = new String[DM];
                for (int i = 1; i <= DM; i++) {
                   days[i-1] = String.valueOf(i);
                }
            return days;
        }
}

    private void jCalendar() {
            //jComboBoxMonth.setModel(new DefaultComboBoxModel<>(DUli.getMonth()));
            String[] yearz = DUli.getYears();
            String[] yearswb = new String[yearz.length + 1];
            yearswb[0] = " - ";
            System.arraycopy(yearz, 0, yearswb, 1, yearz.length);
            jComboBoxYear.setModel(new DefaultComboBoxModel<>(yearswb));
            
            
            //Setting 'em days
            jComboBoxDay.setModel(new DefaultComboBoxModel<>(new String[]{" - "}));
            
            ItemListener refresh = e -> {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    updateDays();
                }
            };
            
            jComboBoxMonth.addItemListener(refresh);
            jComboBoxYear.addItemListener(refresh);
            
}
    
    
    

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Password1 = new javax.swing.JPasswordField();
        jLabel6 = new javax.swing.JLabel();
        Password2 = new javax.swing.JPasswordField();
        Editor = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jRadioButton3 = new javax.swing.JRadioButton();
        jLabel11 = new javax.swing.JLabel();
        jComboBoxMonth = new javax.swing.JComboBox<>();
        jComboBoxDay = new javax.swing.JComboBox<>();
        jComboBoxYear = new javax.swing.JComboBox<>();
        jCheckBox1 = new javax.swing.JCheckBox();
        Register = new javax.swing.JButton();
        jTextField3 = new javax.swing.JTextField();
        FirstName = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Register");
        if (Reg != null) setIconImage(Reg.getImage());
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        jLabel1.setFont(new java.awt.Font("Comic Sans MS", 1, 26)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Register Account");

        if (red != null) jLabel5.setIcon(red);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(113, 113, 113)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(189, 189, 189))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(jLabel1)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextField1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField1FocusLost(evt);
            }
        });
        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextField1KeyTyped(evt);
            }
        });
        jPanel2.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 140, 307, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel2.setText("Username:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, -1, 20));

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel3.setText("Password:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 180, -1, 19));

        Password1.setEchoChar('\u0000');
        Password1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                Password1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                Password1FocusLost(evt);
            }
        });
        Password1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Password1ActionPerformed(evt);
            }
        });
        jPanel2.add(Password1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 180, 309, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel6.setText("Re-Enter Password:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 220, -1, 22));

        Password2.setEchoChar('\u0000');
        Password2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                Password2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                Password2FocusLost(evt);
            }
        });
        jPanel2.add(Password2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 220, 309, -1));

        Editor.setText("Edit");
        Editor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditorActionPerformed(evt);
            }
        });
        jPanel2.add(Editor, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 390, 105, -1));

        jLabel4.setForeground(new java.awt.Color(248, 70, 70));
        jLabel4.setText("Log in?");
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 420, -1, -1));

        if (notshow != null) jLabel7.setIcon(notshow);
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        jLabel7.setVisible(false);
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 180, 51, 30));

        jLabel8.setVisible(false);
        if (notshow != null) jLabel8.setIcon(notshow);
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 220, 51, 30));

        jLabel9.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel9.setText("Phone #:");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, -1, 22));

        jTextField2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextField2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField2FocusLost(evt);
            }
        });
        jPanel2.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 100, 307, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel10.setText("Date Of Birth:");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 300, -1, -1));

        jRadioButton1.setBackground(new java.awt.Color(153, 153, 153));
        jRadioButton1.setForeground(new java.awt.Color(255, 0, 204));
        jRadioButton1.setText("Female");
        jPanel2.add(jRadioButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 260, -1, -1));

        jRadioButton2.setBackground(new java.awt.Color(153, 153, 153));
        jRadioButton2.setForeground(new java.awt.Color(0, 0, 153));
        jRadioButton2.setText("Male");
        jPanel2.add(jRadioButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 260, -1, -1));

        jLabel12.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel12.setText("First Name:");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, 22));

        jLabel13.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel13.setText("Last Name:");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, -1, 22));

        jTextField4.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextField4FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField4FocusLost(evt);
            }
        });
        jPanel2.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 50, 120, -1));

        jButton1.setBackground(new java.awt.Color(255, 255, 0));
        jButton1.setText("!");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 140, -1, -1));

        jLabel14.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel14.setText("Middle Name:");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 50, -1, 22));

        jRadioButton3.setBackground(new java.awt.Color(153, 153, 153));
        jRadioButton3.setForeground(new java.awt.Color(153, 0, 255));
        jRadioButton3.setText("Rather not say");
        jPanel2.add(jRadioButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 260, -1, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        jLabel11.setText("Gender:");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 260, -1, -1));

        jComboBoxMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" }));
        jComboBoxMonth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxMonthActionPerformed(evt);
            }
        });
        jPanel2.add(jComboBoxMonth, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 300, 100, -1));

        jComboBoxDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-" }));
        jComboBoxDay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxDayActionPerformed(evt);
            }
        });
        jPanel2.add(jComboBoxDay, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 300, 80, -1));

        jComboBoxYear.setModel(new DefaultComboBoxModel<>(DUli.getYears()));
        jPanel2.add(jComboBoxYear, new org.netbeans.lib.awtextra.AbsoluteConstraints(432, 300, 90, -1));

        jCheckBox1.setBackground(new java.awt.Color(153, 153, 153));
        jCheckBox1.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jCheckBox1.setText("No middle name");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });
        jPanel2.add(jCheckBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 80, 110, 10));

        Register.setText("Register");
        Register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegisterActionPerformed(evt);
            }
        });
        jPanel2.add(Register, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 390, 105, -1));

        jTextField3.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextField3FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField3FocusLost(evt);
            }
        });
        jPanel2.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 50, 110, -1));

        FirstName.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                FirstNameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                FirstNameFocusLost(evt);
            }
        });
        FirstName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FirstNameActionPerformed(evt);
            }
        });
        jPanel2.add(FirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 110, -1));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel15.setText("Year");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 330, -1, -1));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel16.setText("Month");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 330, -1, -1));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jLabel17.setText("Day");
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 330, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 455, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void listener() {
        FirstName.addFocusListener(new java.awt.event.FocusAdapter() {
            
            @Override
            public void focusGained(java.awt.event.FocusEvent evt) {
                FirstNameFocusGained(evt);
            }
            
            @Override
            public void focusLost(java.awt.event.FocusEvent evt) {
                FirstNameFocusLost(evt);
            }
        });
        FirstName.addActionListener((java.awt.event.ActionEvent evt) -> {
            FirstNameActionPerformed(evt);
        });
    }
    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        passwordVisible1 = !passwordVisible1;

        if (passwordVisible1 == true) {
            Password2.setEchoChar((char)0);
            if (show != null) jLabel8.setIcon(show);
        }
        else {
            Password2.setEchoChar('*');
            if (notshow != null) jLabel8.setIcon(notshow);
        }
    }//GEN-LAST:event_jLabel8MouseClicked

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked

        passwordVisible = !passwordVisible;

        if (passwordVisible == true) {
            Password1.setEchoChar((char)0);
            if (show != null) jLabel7.setIcon(show);
        }
        else {
            Password1.setEchoChar('*');
            if (notshow != null) jLabel7.setIcon(notshow);
        }
    }//GEN-LAST:event_jLabel7MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
    if (!isReviewed) {
        if (count == 0) {
            // 🔹 FIRST ATTEMPT: Gentle reminder
            JOptionPane.showMessageDialog(
                this,
                "Please click Register first to review your details.",
                "Not Finalized",
                JOptionPane.WARNING_MESSAGE
            );
            count++;  // Increment count for next attempt
        } else {
            // 🔹 SECOND+ ATTEMPT: Different message
            JOptionPane.showMessageDialog(
                this,
                "No Accounts Registered.",
                "Not My Problem",
                JOptionPane.WARNING_MESSAGE
            );
            LOGIN log = new LOGIN();
            log.setVisible(true);
            log.pack();
            log.setLocationRelativeTo(null);
            log.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.dispose();
        }
        return;  // Stop execution here
    }
    
    
    String fullName = getFullName();
    String username = jTextField2.getText();
    String phone = jTextField1.getText();
    String password = String.valueOf(Password1.getPassword());
    String gender;

    if (jRadioButton2.isSelected()) {
        gender = "Male";
    } else if (jRadioButton1.isSelected()) {
        gender = "Female";
    } else {
        gender = "Rather not say";
    }

    String birthdate =
            jComboBoxMonth.getSelectedItem() + " " +
            jComboBoxDay.getSelectedItem() + ", " +
            jComboBoxYear.getSelectedItem();

    try {
        Connection conn = Database.getConnection();

        String sql = "INSERT INTO Table1 "
                   + "(full_name, username, phone, password, gender, birthdate) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";

        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, fullName);
        pst.setString(2, username);
        pst.setString(3, phone);
        pst.setString(4, password);
        pst.setString(5, gender);
        pst.setString(6, birthdate);

        pst.executeUpdate();

        JOptionPane.showMessageDialog(
            this,
            "Account created successfully!",
            "Success",
            JOptionPane.INFORMATION_MESSAGE
        );

    } catch (Exception e) {
        JOptionPane.showMessageDialog(
            this,
            "Database Error:\n" + e.getMessage(),
            "Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
    
    LOGIN log = new LOGIN();
    log.setVisible(true);
    log.pack();
    log.setLocationRelativeTo(null);
    log.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.dispose();
    }//GEN-LAST:event_jLabel4MouseClicked

    private void EditorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditorActionPerformed
        jTextField3.setEnabled(true);
        FirstName.setEnabled(true);
        jTextField4.setEnabled(true);
        jTextField2.setEnabled(true);
        jTextField1.setEnabled(true);
        Password1.setEnabled(true);
        Password2.setEnabled(true);
        jComboBoxMonth.setEnabled(true);
        jComboBoxDay.setEnabled(true);
        jComboBoxYear.setEnabled(true);
        jRadioButton2.setEnabled(true);
        jRadioButton1.setEnabled(true);
        jRadioButton3.setEnabled(true);
        jCheckBox1.setEnabled(true);
        
        isReviewed = false;
    }//GEN-LAST:event_EditorActionPerformed
    private String getFullName() {
    String first = FirstName.getText().trim();
    String mid   = jTextField3.getText().trim();
    String last  = jTextField4.getText().trim();

    String fullName;

    if (mid.equalsIgnoreCase("N/A") || mid.equalsIgnoreCase("Middle Name")) {
        fullName = first + " " + last;
    } else {
        fullName = first + " " + mid + " " + last;
    }

    return fullName.replaceAll("\\s+", " ").trim();
}

    private void Password2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Password2FocusLost
        if(String.valueOf(Password2.getPassword()).length()==0) {
            Password2.setText("Re-Enter Password");
            Password2.setEchoChar((char)0);
            Password2.setForeground(Color.GRAY);
            jLabel8.setVisible(false);

        }
    }//GEN-LAST:event_Password2FocusLost

    private void Password2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Password2FocusGained
        jLabel8.setVisible(true);

        if(String.valueOf(Password2.getPassword()).equals("Re-Enter Password")) {
            Password2.setText(null);

            Password2.setEchoChar('*');
            Password2.setForeground(Color.BLACK);
            
            Password2.repaint();
        }
    }//GEN-LAST:event_Password2FocusGained

    private void Password1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Password1FocusLost
        if(String.valueOf(Password1.getPassword()).length()==0) {
            Password1.setText("Enter Password");
            Password1.setEchoChar((char)0);
            Password1.setForeground(Color.GRAY);
            jLabel7.setVisible(false);

        }
    }//GEN-LAST:event_Password1FocusLost

    private void Password1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_Password1FocusGained
        jLabel7.setVisible(true);

        if(String.valueOf(Password1.getPassword()).equals("Enter Password")) {
            Password1.setText("");

            Password1.setEchoChar('*');
            Password1.setForeground(Color.BLACK);
            
            Password1.repaint();

        }
    }//GEN-LAST:event_Password1FocusGained

    private void jTextField1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField1FocusLost
        if (jTextField1.getText().length()==0) {
            jTextField1.setText("Enter Phone Number");
            jTextField1.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_jTextField1FocusLost

    private void jTextField1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField1FocusGained
        if (jTextField1.getText().equals("Enter Phone Number")) {
            jTextField1.setText("");
            jTextField1.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_jTextField1FocusGained

    private void jTextField2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField2FocusGained
        if (jTextField2.getText().equals("Enter Username")) {
            jTextField2.setText("");
            jTextField2.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_jTextField2FocusGained

    private void jTextField2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField2FocusLost
        if (jTextField2.getText().length()==0) {
            jTextField2.setText("Enter Username");
            jTextField2.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_jTextField2FocusLost

    private void jTextField4FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField4FocusGained
        if (jTextField4.getText().equals("Last Name")) {
            jTextField4.setText("");
            jTextField4.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_jTextField4FocusGained

    private void jTextField4FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField4FocusLost
        if (jTextField4.getText().length()==0) {
            jTextField4.setText("Last Name");
            jTextField4.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_jTextField4FocusLost

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        JOptionPane.showMessageDialog(this, "Please Use a Real Phone Number, This will be Useful when recovering Account.");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        if (jCheckBox1.isSelected()) {
            jTextField3.setText("N/A");
            jTextField3.setForeground(Color.GRAY);
            jTextField3.setEnabled(false);
        }
        else {
            jTextField3.setText("Middle Name");
            jTextField3.setForeground(Color.GRAY);
            jTextField3.setEnabled(true);
        }
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jTextField1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField1KeyTyped
        char c = evt.getKeyChar();
        
        if (!Character.isDigit(c)) {
            evt.consume();
        }
    }//GEN-LAST:event_jTextField1KeyTyped

    private void RegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegisterActionPerformed
        String first = FirstName.getText();
        String mid   = jTextField3.getText();
        String last  = jTextField4.getText();
        String user = jTextField2.getText();
        String phone = jTextField1.getText();
        String password = String.valueOf(Password1.getPassword());
        String repassword = String.valueOf(Password2.getPassword());
        String month = jComboBoxMonth.getSelectedItem().toString();
        String day = jComboBoxDay.getSelectedItem().toString();
        String year = jComboBoxYear.getSelectedItem().toString();
        String gender;
        
        
        
        if (jRadioButton2.isSelected()) {
            gender = "Male";
        } else if (jRadioButton1.isSelected()) {
            gender = "Female";
        } else {
            gender = "Rather not say";
        }
        
        if (first.isEmpty() || mid.isEmpty() || last.isEmpty() || user.isEmpty() || password.isEmpty() || repassword.isEmpty() || phone.isEmpty() || month.equals(" - ") ||
            day.equals(" - ") || year.equals(" - ") || gender.isEmpty()  ) {
            
            JOptionPane.showMessageDialog(null, "Some Fields are Blank.", "Please Fill out all the Fields", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (!password.equals(repassword)) { 
            JOptionPane.showMessageDialog(null, "The Password and Re-Enter Password Doesn't match", "Password Mismatch", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        JOptionPane.showMessageDialog(null, "Warning: You can't change when going back to 'Log-in', Make sure to Finalize everything.", "Registered Successfully!", JOptionPane.INFORMATION_MESSAGE);
        jTextField3.setEnabled(false);
        FirstName.setEnabled(false);
        jTextField4.setEnabled(false);
        jTextField2.setEnabled(false);
        jTextField1.setEnabled(false);
        Password1.setEnabled(false);
        Password2.setEnabled(false);
        jComboBoxMonth.setEnabled(false);
        jComboBoxDay.setEnabled(false);
        jComboBoxYear.setEnabled(false);
        jRadioButton2.setEnabled(false);
        jRadioButton1.setEnabled(false);
        jRadioButton3.setEnabled(false);
        jCheckBox1.setEnabled(false);
        
        isReviewed = true;
    }//GEN-LAST:event_RegisterActionPerformed

    private void jTextField3FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField3FocusGained
        if (jTextField3.getText().equals("Middle Name")) {
            jTextField3.setText("");
            jTextField3.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_jTextField3FocusGained

    private void jTextField3FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField3FocusLost
        if (jTextField3.getText().length()==0) {
            jTextField3.setText("Middle Name");
            jTextField3.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_jTextField3FocusLost

    private void FirstNameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_FirstNameFocusGained
        if (FirstName.getText().equals("First Name")) {
            FirstName.setText("");
            FirstName.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_FirstNameFocusGained

    private void FirstNameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_FirstNameFocusLost
        if (FirstName.getText().length()==0) {
            FirstName.setText("First Name");
            FirstName.setForeground(Color.GRAY);
        }
    }//GEN-LAST:event_FirstNameFocusLost

    private void FirstNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FirstNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FirstNameActionPerformed

    private void Password1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Password1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Password1ActionPerformed

    private void jComboBoxMonthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxMonthActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxMonthActionPerformed

    private void jComboBoxDayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxDayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxDayActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(REGISTER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(REGISTER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(REGISTER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(REGISTER.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new REGISTER().setVisible(true);
        });
    }
        
        public void updateDays() {
            int inty = jComboBoxYear.getSelectedIndex();
                if (inty == 0) {
                    inty = -1;
                }
                else {
                    Integer.valueOf(jComboBoxYear.getSelectedItem().toString());
                }
            int intm = jComboBoxMonth.getSelectedIndex() - 1;
            
            if (inty < 0 || intm < 0) {
                jComboBoxDay.setModel(new DefaultComboBoxModel<>(new String[] {" - "}));
                return;
            }
            
            int OI = jComboBoxDay.getSelectedIndex();
            
            int CHIKAWA;
            String[] dayss = DUli.getDays(inty, intm);
            String[] dawb = new String[dayss.length + 1];
            dawb[0] = " - ";
            System.arraycopy(dayss, 0, dawb, 1, dayss.length);
            jComboBoxDay.setModel(new DefaultComboBoxModel<>(dawb));
            
            if (OI > 0 && OI <= dayss.length) {
                CHIKAWA = OI; 
            }
            else if (OI > dayss.length) {
                CHIKAWA = dayss.length;
            }
            else {
                CHIKAWA = 0;
            }
            
            jComboBoxDay.setSelectedIndex(CHIKAWA);
        }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Editor;
    private javax.swing.JTextField FirstName;
    private javax.swing.JPasswordField Password1;
    private javax.swing.JPasswordField Password2;
    private javax.swing.JButton Register;
    private javax.swing.JButton jButton1;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JComboBox<String> jComboBoxDay;
    private javax.swing.JComboBox<String> jComboBoxMonth;
    private javax.swing.JComboBox<String> jComboBoxYear;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    // End of variables declaration//GEN-END:variables
}
