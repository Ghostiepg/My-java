
package com.mycompany.mavenproject1;

import Characters.Characters;
import Prop_Coding.Bomb;
import java.awt.Rectangle;

public class CollisionChecka {
    GamePanel gp;
    
    public CollisionChecka(GamePanel gp) {
        this.gp = gp;
    }
    public void checkTile(Characters charac) {
        // Compute the character's bounding box in pixel space and identify
        // the tile columns/rows occupied before and after moving by 'speed'.
        
        int CharacterLeftx = charac.x + charac.solidArea.x;
        int CharacterRightx = charac.x + charac.solidArea.x + charac.solidArea.width;
        int CharacterTopy = charac.y + charac.solidArea.y;
        int CharacterBottomy = charac.y + charac.solidArea.y + charac.solidArea.height;
        
        int CharacterLeftCol = CharacterLeftx/gp.TS;
        int CharacterRightCol = CharacterRightx/gp.TS;
        int CharacterTopRow = CharacterTopy/gp.TS;
        int CharacterBottomRow = CharacterBottomy/gp.TS;
        
        int TN1, TN2;
        
        switch (charac.direction) {
            case "up":
                CharacterTopRow = (CharacterTopy - charac.speed)/gp.TS;
                TN1 = gp.tileM.MTN[CharacterLeftCol][CharacterTopRow];
                TN2 = gp.tileM.MTN[CharacterRightCol][CharacterTopRow];
                
                    if ((gp.tileM.tile[TN1].collision && TN1 == 2) || 
                        (gp.tileM.tile[TN2].collision && TN2 == 2)) {
                        charac.collisionON = true;
                    }
                
                break;
            case "down":
                CharacterBottomRow = (CharacterBottomy + charac.speed)/gp.TS;
                TN1 = gp.tileM.MTN[CharacterLeftCol][CharacterBottomRow];
                TN2 = gp.tileM.MTN[CharacterRightCol][CharacterBottomRow];
                
                    if ((gp.tileM.tile[TN1].collision && TN1 == 2) || 
                        (gp.tileM.tile[TN2].collision && TN2 == 2)) {
                        charac.collisionON = true;
                    }
                break;    
            case "left":
                CharacterLeftCol = (CharacterLeftx - charac.speed)/gp.TS;
                TN1 = gp.tileM.MTN[CharacterLeftCol][CharacterTopRow];
                TN2 = gp.tileM.MTN[CharacterLeftCol][CharacterBottomRow];
                
                    if ((gp.tileM.tile[TN1].collision && TN1 == 2) || 
                        (gp.tileM.tile[TN2].collision && TN2 == 2)) {
                        charac.collisionON = true;
                    }
                break;
            case "right":
                CharacterRightCol = (CharacterRightx + charac.speed)/gp.TS;
                TN1 = gp.tileM.MTN[CharacterRightCol][CharacterTopRow];
                TN2 = gp.tileM.MTN[CharacterRightCol][CharacterBottomRow];
                
                if ((gp.tileM.tile[TN1].collision && TN1 == 2) || 
                    (gp.tileM.tile[TN2].collision && TN2 == 2)) {
                    charac.collisionON = true;
                }
                break;
        }
        Rectangle bluebox = new Rectangle(charac.x + charac.solidArea.x, charac.y + charac.solidArea.y, charac.solidArea.width, charac.solidArea.height);
        
        for (Bomb z : new java.util.ArrayList<>(charac.gp.bombs)) {
            // Prevent stepping onto bombs (except the one just placed by this character)
            Rectangle bomboclat = new Rectangle (z.x * charac.gp.TS, z.y * charac.gp.TS, charac.gp.TS, charac.gp.TS);
        
        int cx = (charac.x + charac.gp.TS / 2) / charac.gp.TS;
        int cy = (charac.y + charac.gp.TS / 2) / charac.gp.TS;
        
        // For all characters
            boolean isOwnBomb = (charac.LBX == z.x && charac.LBY == z.y);
            if (bluebox.intersects(bomboclat) && !isOwnBomb) {
                charac.collisionON = true;
            }

       }
                
    }
    
}
