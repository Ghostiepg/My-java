package com.mycompany.mavenproject1;

import java.sql.Connection;
import java.sql.DriverManager;

public class Testing {

    private Connection connect() {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

            String url = "jdbc:ucanaccess://D:/Documents/database.accdb";
            return DriverManager.getConnection(url);

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
