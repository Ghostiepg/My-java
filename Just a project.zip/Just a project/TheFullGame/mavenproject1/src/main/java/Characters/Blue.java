/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Characters;

import com.mycompany.mavenproject1.*;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public final class Blue extends Characters {
    // Represents the Player 1 character. Inherits position/speed/collision from Characters.
    // Handles movement via WASD keys and plays animated GIF sprites for direction and death.

    private static Image loadImg(String path) {
        // Utility to load an Image from classpath; returns null if not found
        if (path == null) return null;
        java.net.URL url = Blue.class.getResource(path);
        return (url != null) ? new ImageIcon(url).getImage() : null;
    }

    GamePanel qp;
    KeyInputs keyH;
    public boolean alive = true;
    Image death;
    public int DT = 45;
    public int players = 1; // 1 = single player, 2 = multiplayer
    private static final GifDecoder DEATH_DECODER = new GifDecoder("/resources/Models/Blue_Death.gif");
    private long deathFrameTime = 0;

    
    
    
    Image up1, down1, left, right;
    
    public Blue(GamePanel qp, KeyInputs keyH) {
        super(qp);
        this.qp = qp;
        this.keyH = keyH;
        this.LBX = -1;
        this.LBY = -1;
        
        
        solidArea = new Rectangle();
        solidArea.x = 8;
        solidArea.y = 12;
        solidArea.width = 33;
        solidArea.height = 33;
        // solidArea defines the collision box used in tile/bomb collision checks
       
        // Load direction GIFs and death animation
        this.up1 = loadImg("/resources/Models/Up1.gif");
        this.down1 = loadImg("/resources/Models/Down1.gif");
        this.left = loadImg("/resources/Models/Left.gif");
        this.right = loadImg("/resources/Models/Right.gif");
        this.death = loadImg("/resources/Models/Blue_Death.gif");

        
        
    }
    
    

   
    
    public void kill() {
        // Transitions to "dead" state and starts a death animation countdown (DT)
        if (!alive) return;
        
        this.alive = false;
        DT = 45;
        
        
    }
    
    
    
   public void update() {

    // ----- Death handling -----
    if (!alive) {
        if (DT > 0) {
            DT--;   // countdown death animation
        }
        return;     // stop movement while dead
    }

    // ----- Movement handling -----
    collisionON = false;

    if (keyH.up) direction = "up";
    else if (keyH.down) direction = "down";
    else if (keyH.left) direction = "left";
    else if (keyH.right) direction = "right";
    else direction = "";

    if (!direction.isEmpty()) {

        qp.CC.checkTile(this);

        if (!collisionON) {
            switch(direction) {
                case "up": y -= speed; break;
                case "down": y += speed; break;
                case "left": x -= speed; break;
                case "right": x += speed; break;
            }
        }
    }
}




        // Select appropriate sprite based on current state/direction and draw scaled to tile size
    
    public void draw(Graphics2D g2) {
        Image image;
        if (!alive) {
            if (DT > 0) image = death;
            else return;
        } else {
            switch (direction) {
                case "up": image = up1; break;
                case "down": image = down1; break;
                case "left": image = left; break;
                case "right": image = right; break;
                default: image = down1; break;
            }
        }
        if (image != null) g2.drawImage(image, x, y, qp.TS, qp.TS, qp);

    }
}
