/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Characters;

import com.mycompany.mavenproject1.GamePanel;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

public class Characters {
    public GamePanel gp;
    public int x, y;
    public final int speed = 4; // ✅ Make it final and set to 4
    public int LBX;
    public int LBY;
    
    public java.awt.Image up1, down1, left, right;
    public String direction = "";
    
    public int SC = 0;
    public int SN = 1;
    public Rectangle solidArea;
    public boolean collisionON = false;
    
    
    public Characters(GamePanel gp){
        this.gp = gp;
    }
    
}
