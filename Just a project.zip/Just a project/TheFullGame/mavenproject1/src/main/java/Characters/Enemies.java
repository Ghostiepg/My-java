/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Characters;

import com.mycompany.mavenproject1.*;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public final class Enemies extends Characters {
    // Simple AI entity: moves randomly every ~60 ticks, collides with tiles/bombs, dies to explosions or contact.

    private static Image loadImg(String path) {
        // Load an Image from classpath for enemy and death GIFs
        if (path == null) return null;
        java.net.URL url = Enemies.class.getResource(path);
        return (url != null) ? new ImageIcon(url).getImage() : null;
    }

    GamePanel qp;
    Random random = new Random();
    public boolean alive = true;
    Image death;
    public int DT = 60;
    public int mc = 0;
    
    
    
    
    
    
    Image enemy;
    
    public Enemies(GamePanel qp, int spawnX, int spawnY) {
        super(qp);
        this.qp = qp;
        
        this.LBX = -1;
        this.LBY = -1;
        
        
        solidArea = new Rectangle();
        solidArea.x = 8;
        solidArea.y = 12;
        solidArea.width = 33;
        solidArea.height = 33;
        
        this.x = spawnX * qp.TS;
        this.y = spawnY * qp.TS;
        
        direction = "enemy";
        
        
        this.enemy = loadImg("/resources/Models/Enemy.gif");
        this.death = loadImg("/resources/Models/DestroyEnemy.gif");
        
        
    }
    
    

    
    
    public void kill() {
        // Enter dead state and start death animation countdown
        if (!alive) return;
        
        this.alive = false;
        DT = 60;
    }
    
    
    
    public void update() {
    // Advance AI movement or death countdown per update tick
    if (!alive) {
        if (DT > 0) {
            DT--;
        }
        return;
    }

    mc++;
    if (mc > 60) {
        // Pick a random direction roughly once per second at 60 FPS
        int randDir = random.nextInt(4);
        switch (randDir) {
            case 0 -> direction = "up";
            case 1 -> direction = "down";
            case 2 -> direction = "left";
            case 3 -> direction = "right";
        }
        mc = 0;
    }

    collisionON = false;             // reset collision
    qp.CC.checkTile(this);           // check walls & bombs

    if (!collisionON) {              // move if no collision
        switch(direction) {
            case "up" -> y -= speed;
            case "down" -> y += speed;
            case "left" -> x -= speed;
            case "right" -> x += speed;
        }
    }
}

    public void draw(Graphics2D g2) {
        // Draw enemy alive GIF or death GIF while DT > 0
        Image image = alive ? enemy : (DT > 0 ? death : null);
        if (image != null) g2.drawImage(image, x, y, qp.TS, qp.TS, qp);
    }
}
