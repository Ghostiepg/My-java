package Characters;

import com.mycompany.mavenproject1.*;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public final class Red extends Characters {
    // Represents Player 2 character controlled via Arrow keys and M for bomb.
    // Movement/collision mirrors Blue, with its own GIF sprites and death timer.

    private static final Image UP1_IMG = loadImg("/resources/Models/Up2.gif");
    private static final Image DOWN1_IMG = loadImg("/resources/Models/Down2.gif");
    private static final Image LEFT_IMG = loadImg("/resources/Models/Left2.gif");
    private static final Image RIGHT_IMG = loadImg("/resources/Models/Right2.gif");
    private static final Image DEATH_IMG = loadImg("/resources/Models/Red_Death.gif");

    private static Image loadImg(String path) {
        if (path == null) return null;
        java.net.URL url = Red.class.getResource(path);
        if (url == null) {
            System.out.println("ERROR: Image not found at path: " + path);
            return null;
        }
        Image img = new ImageIcon(url).getImage();
        System.out.println("Image loaded: " + path + " = " + (img != null ? "SUCCESS" : "FAILED"));
        return img;
    }

    GamePanel qp;
    KeyInputs keyR;
    public boolean alive = true;
    Image death;
    public int DT = 60;
    public int players = 2;
    
    public long firstHitTime = 0;
    public int iFrameDuration = 30; 

    // ? REMOVED duplicate image fields - inherited from Characters parent!

    public Red(GamePanel qp, KeyInputs keyR) {
        super(qp);
        this.qp = qp;
        this.keyR = keyR;
        this.LBX = -1;
        this.LBY = -1;

        solidArea = new Rectangle();
        solidArea.x = 8;
        solidArea.y = 12;
        solidArea.width = 24;
        solidArea.height = 24;

        this.up1 = UP1_IMG;
        this.down1 = DOWN1_IMG;
        this.left = LEFT_IMG;
        this.right = RIGHT_IMG;
        this.death = DEATH_IMG;

        // ✅ DEBUG: Check if death image loaded
        if (this.death == null) {
            System.out.println("ERROR: Red death image is null! Check path: /resources/Models/Red_Death.gif");
        } else {
            System.out.println("SUCCESS: Red death image loaded!");
        }
    }

    public void kill() {
        if (!alive) return;
        this.alive = false;
        DT = 60;
        firstHitTime = System.currentTimeMillis();
        System.out.println("Red killed! alive=" + alive + ", DT=" + DT + ", firstHitTime=" + firstHitTime);
    }

    public void update() {
        // ---- Death handling ----
        if (!alive) {
            if (DT > 0) {
                DT--;
                if (DT == 59 || DT == 30 || DT == 0) {
                    System.out.println("Red DT: " + DT);
                }
            }
            return; // stop movement while dead
        }

        // ---- Movement ----
        collisionON = false;

        // ✅ DEBUG: Log key states
        System.out.println("Red KeyStates: aup=" + keyR.aup + ", adown=" + keyR.adown + 
                          ", aleft=" + keyR.aleft + ", aright=" + keyR.aright);

        if (keyR.aup) direction = "up";
        else if (keyR.adown) direction = "down";
        else if (keyR.aleft) direction = "left";
        else if (keyR.aright) direction = "right";
        else direction = "";

        System.out.println("Red Direction: " + direction);

        if (!direction.isEmpty()) {
            qp.CC.checkTile(this);

            if (!collisionON) {
                switch(direction) {
                    case "up": y -= speed; break;
                    case "down": y += speed; break;
                    case "left": x -= speed; break;
                    case "right": x += speed; break;
                }
            }
        }
    }

    public void draw(Graphics2D g2) {
        if (!alive) {
            if (DT > 0) {
                // ✅ Fade out effect based on DT
                if (death != null) {
                    // Calculate alpha (0.0-1.0) based on DT
                    float alpha = (float) DT / 60.0f;
                    
                    // ✅ Use AlphaComposite for image transparency
                    AlphaComposite ac = AlphaComposite.getInstance(
                        AlphaComposite.SRC_OVER, alpha);
                    g2.setComposite(ac);
                    g2.drawImage(death, x, y, qp.TS, qp.TS, qp);
                    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1.0f));
                } else {
                    System.out.println("ERROR: Red death image is null!");
                    // ✅ Fallback: Draw a red rectangle
                    g2.setColor(Color.RED);
                    g2.fillRect(x, y, qp.TS, qp.TS);
                }
            }
            // ✅ When DT reaches 0, don't draw anything (character disappears)
            return;
        } else {
            Image image;
            // ✅ DEBUG: Log which image is being selected
            System.out.println("Red draw: direction=" + direction);
            switch (direction) {
                case "up": image = up1; break;
                case "down": image = down1; break;
                case "left": image = left; break;
                case "right": image = right; break;
                default: image = down1; break;
            }
            if (image != null) {
                g2.drawImage(image, x, y, qp.TS, qp.TS, qp);
            } else {
                System.out.println("ERROR: Red image is null for direction: " + direction);
                // ✅ Fallback: Draw a colored rectangle
                g2.setColor(Color.RED);
                g2.fillRect(x, y, qp.TS, qp.TS);
            }
        }
    }
}
