package Prop_Coding;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;

public class Bomb {
    // Represents a placed bomb on a tile grid. Tracks timer until explosion (ECD),
    // when it spawns rectangles for center and each arm into ahitbox for collision checks.
    
    // ✅ Load images ONCE as static variables
    private static final Image BOMB_IMAGE = loadImage("/resources/Pickable/Bomb.gif");
    private static final Image EXPLODE_IMAGE = loadImage("/resources/Pickable/BombExplode.gif");
    
    public int x, y;
    public boolean exploded = false;
    public int timer = 0;
    public int ECD = 60;
    public int range = 1;
    public Image bomb;
    public Image c, l, r, u, d;
    public Image lp, rp, upp, dpp;
    public boolean damageChecked = false;
    public boolean isUsed = false; // ✅ Add this flag
    public ArrayList<Rectangle> ahitbox = new ArrayList<>();
    
    private static Image loadImage(String path) {
        // Load an Image from classpath and return a shared instance
        if (path == null) return null;
        java.net.URL url = Bomb.class.getResource(path);
        if (url == null) return null;
        return new ImageIcon(url).getImage();
    }

    public Bomb(int x, int y) {
        this.x = x;
        this.y = y;
        this.isUsed = (x != -1 && y != -1);
        
        // ✅ Just assign the static images (no loading from disk!)
        this.bomb = BOMB_IMAGE;
        this.c = EXPLODE_IMAGE;
        this.l = EXPLODE_IMAGE;
        this.r = EXPLODE_IMAGE;
        this.u = EXPLODE_IMAGE;
        this.d = EXPLODE_IMAGE;
        this.lp = EXPLODE_IMAGE;
        this.rp = EXPLODE_IMAGE;
        this.upp = EXPLODE_IMAGE;
        this.dpp = EXPLODE_IMAGE;
    }
}
