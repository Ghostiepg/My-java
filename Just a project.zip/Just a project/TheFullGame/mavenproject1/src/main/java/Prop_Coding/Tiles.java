/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prop_Coding;

import java.awt.image.BufferedImage;

public class Tiles {
    
    public BufferedImage image;
    public boolean collision = false;
    
}
