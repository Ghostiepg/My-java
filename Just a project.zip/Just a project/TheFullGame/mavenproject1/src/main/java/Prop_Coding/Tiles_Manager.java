/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Prop_Coding;

import com.mycompany.mavenproject1.GamePanel;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

public class Tiles_Manager {
    // Responsible for all tile data: images, collision flags, and the map grid (MTN).
    // Generates a bomberman-style map and draws it scaled to the GamePanel tile size.
    
    GamePanel gp;
    public Tiles[] tile;
    public int MTN[][];
    
    public Tiles_Manager(GamePanel gp) {
        this.gp = gp;
        
        tile = new Tiles[10];
        MTN = new int[gp.MSC][gp.MSR];
        
        
        
        getTileImage();
        loadMap();
        
    }
    
    public void getTileImage() {
        try {
            tile[0] = new Tiles();
            tile[0].image = readImage("/resources/Props_n_stuff/Grass.png");

            tile[1] = new Tiles();
            tile[1].image = readImage("/resources/Props_n_stuff/B_Brick.png");
            tile[1].collision = true;

            tile[2] = new Tiles();
            tile[2].image = readImage("/resources/Props_n_stuff/UB_Brick.png");
            tile[2].collision = true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Could not load some tile images. Place PNGs in src/main/resources/resources/Props_n_stuff/ (Grass.png, B_Brick.png, UB_Brick.png)");
        }
    }

    private java.awt.image.BufferedImage readImage(String path) throws IOException {
        try (InputStream in = getClass().getResourceAsStream(path)) {
            return (in != null) ? ImageIO.read(in) : null;
        }
    }
    
    public void loadMap() {

    for (int col = 0; col < gp.MSC; col++) {
        for (int row = 0; row < gp.MSR; row++) {

            // Border walls (unbreakable)
            if (col == 0 || row == 0 || col == gp.MSC - 1 || row == gp.MSR - 1) {
                MTN[col][row] = 2;
            }

            // Solid pattern walls like classic bomberman
            else if (col % 2 == 0 && row % 2 == 0) {
                MTN[col][row] = 2;
            }

            // Random breakable walls
            else {
                double random = Math.random();

                if (random < 0.4) {   // 40% chance
                    MTN[col][row] = 1;   // breakable brick
                } else {
                    MTN[col][row] = 0;   // grass
                }
            }
        }
    }

    // Clear spawn area for players
    MTN[1][1] = 0;
    MTN[1][2] = 0;
    MTN[2][1] = 0;

    MTN[gp.MSC - 2][gp.MSR - 2] = 0;
    MTN[gp.MSC - 2][gp.MSR - 3] = 0;
    MTN[gp.MSC - 3][gp.MSR - 2] = 0;
}

    
    public void draw(Graphics2D g2) {
        // Stream tiles left-to-right then top-to-bottom, drawing each tile image scaled to tile size
        
        int col = 0;
        int row = 0;
        int x = 0;
        int y = 0;
        
        while (col < gp.MSC && row < gp.MSR) {
            int TN = MTN[col][row];
            if (tile[TN].image != null) {
                g2.drawImage(tile[TN].image, x, y, gp.TS, gp.TS, null);
            }
            col++;
            x += gp.TS;
            
            if (col == gp.MSC) {
                col = 0;
                x = 0;
                row++;
                y += gp.TS;
            }
        }
    }

    public void reloadMap() {
        loadMap();
    }
    
    
}
